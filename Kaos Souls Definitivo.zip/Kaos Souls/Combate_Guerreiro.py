import pygame
from pygame.locals import *
import sys
import random

pygame.init()

largura = 1000
altura = 800
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Combate")

branco = (255, 255, 255)
preto = (0, 0, 0)
vermelho = (255, 0, 0)

fonte = pygame.font.SysFont("Arial", 24)
#imagem do personagem do jogador e do inimigo, tá do mago mas era para quando eu estava testando
img_fundo_combate= pygame.image.load('imagens/img_fundo_selecao_de_personagens.jpg')
img_guerreiro = pygame.image.load('imagens/guerreiro_combate.png')
img_esqueleto = pygame.image.load('imagens/Esqueleto.png')
pos_guerreiro = img_guerreiro.get_rect(bottomleft=(100, 700))
pos_esqueleto = img_esqueleto.get_rect(topright=(900, 350))


guerreiro = ["Guerreiro", 50, 0, 10, 10]
esqueleto = ["Esqueleto", 100, 0, 5, 16]

resultado_combate = None

def desenhar_tela(turno):
    tela.blit(img_fundo_combate,(0,0))
    tela.blit(img_guerreiro, pos_guerreiro)
    tela.blit(img_esqueleto, pos_esqueleto)
    pygame.draw.rect(tela, branco, (0, 700, largura, 100))
    global pos_texto_atacar, pos_texto_descansar, pos_texto_fugir
    #texto das escolhas
    texto_atacar = fonte.render("Atacar", True, preto)
    texto_descansar = fonte.render("Descansar", True, preto)
    texto_fugir = fonte.render("Fugir", True, preto)
    #Posição das escolhas
    pos_texto_atacar = texto_atacar.get_rect(center=(165, 750))
    pos_texto_descansar = texto_descansar.get_rect(center=(500, 750))
    pos_texto_fugir = texto_fugir.get_rect(center=(830, 750))
    #Mostrar opções na tela
    tela.blit(texto_atacar, pos_texto_atacar)
    tela.blit(texto_descansar, pos_texto_descansar)
    tela.blit(texto_fugir, pos_texto_fugir)
    # Texto que mostra o turno
    texto_turno = fonte.render(f"Turno: {turno}", True, branco)
    pos_texto_turno = texto_turno.get_rect(topright=(largura - 20, 20))
    tela.blit(texto_turno, pos_texto_turno)
    # Status do guerreiro
    texto_status_guerreiro = fonte.render(f"Guerreiro - Vida: {guerreiro[1]} Estamina: {guerreiro[4]}", True, branco)
    pos_texto_status_guerreiro = texto_status_guerreiro.get_rect(bottomright=(980, 680))
    tela.blit(texto_status_guerreiro, pos_texto_status_guerreiro)
    # Status do esqueleto, aqui acho que, se fossemos coloca mais inimigos, precisariamos criar um def aqui, com todos os status inimigos
    texto_status_esqueleto = fonte.render(f"Esqueleto - Vida: {esqueleto[1]} Estamina: {esqueleto[4]}", True, branco)
    pos_texto_status_esqueleto = texto_status_esqueleto.get_rect(bottomleft=(20, 45))
    tela.blit(texto_status_esqueleto, pos_texto_status_esqueleto)
    pygame.display.flip()

def combate_guerreiro():
    global resultado_combate
    turno = 1
    acao_guerreiro = False
    while True:
        desenhar_tela(turno)
        if not acao_guerreiro:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == MOUSEBUTTONDOWN:
                    x, y = event.pos
                    # Nessa parte deu uma nostalgia, eu fui salvo pela prova de Raciocinio algoritimo, de comparação de status de carro 
                    if pos_texto_atacar.collidepoint(x, y):
                        if guerreiro[4] >= 2:
                            print("Guerreiro atacou!")
                            esqueleto[1] -= guerreiro[3]
                            guerreiro[4] -= 2
                            acao_guerreiro = True
                        else:
                            print("Guerreiro está sem estamina para atacar!")
                    elif pos_texto_descansar.collidepoint(x, y):
                        print("Guerreiro descansou!")
                        guerreiro[4] = 10
                        acao_guerreiro = True
                    elif pos_texto_fugir.collidepoint(x, y):
                        print("Guerreiro fugiu!")
                        resultado_combate = "Fugir"
                        pygame.quit()
                        sys.exit()
        else:
            acao_guerreiro = False
            if esqueleto[1] <= 0:
                print("Guerreiro venceu!")
                pygame.quit()
                sys.exit()
            elif guerreiro[1] <= 0:
                print("Esqueleto venceu!")
                pygame.quit()
                sys.exit()
            else:
                acao_esqueleto = random.choice(["atacar", "descansar"])
                if acao_esqueleto == "atacar" and esqueleto[4] >= 2:
                    print("Esqueleto ataca!")
                    guerreiro[1] -= esqueleto[3]
                    esqueleto[4] -= 2
                elif acao_esqueleto == "descansar":
                    print("Esqueleto descansa!")
                    esqueleto[4] = 10
                turno += 1
combate_guerreiro()