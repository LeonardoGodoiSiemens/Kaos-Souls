import pygame
from pygame.locals import *
from sys import exit
#Notas para mim mesmo e para quem for ver o código: Eu deixei vários desses "#" pelo código para eu não me perder e para anotações para eu não esquecer, então se nas ntoas tiver algo esquisito que não faz sentido, provavelmente foi de algum erro que encontrei e arrumei. Também vou querer anotar a localização de tudo para facilitar
pygame.init()

#Tamanho tela
largura = 1000
altura = 800

tela = pygame.display.set_mode((largura,altura))
pygame.display.set_caption("Kaos Souls")

# Cores do menu
preto = (0, 0, 0)
branco = (255, 255, 255)
vermelho = (255, 0, 0)
vermelho_escuro = (120, 0, 0)
azul = (0, 0, 255)
azul_claro = (0, 0, 200)

# Fonte do Título e do Botão de Iniciar, junto com as posições
titulo_fonte = pygame.font.SysFont("Garamond", 64)
iniciar_fonte = pygame.font.SysFont("Times New Roman", 32)

titulo_jogo = titulo_fonte.render("Kaos Souls", True, vermelho)
iniciar_jogo = iniciar_fonte.render("Iniciar", True, preto)

posicao_titulo = titulo_jogo.get_rect(center=(500, 350))
posicao_iniciar = iniciar_jogo.get_rect(center=(500, 450))

#Imagem teste do fundo do jogo(resolução não tá certa)
img_fundo_menu = pygame.image.load('imagens/imagem_resolucao_certa2.jpg')
img_fundo_selecao_de_personagem=pygame.image.load('imagens/img_fundo_selecao_de_personagens.jpg')
img_mapa=pygame.image.load('imagens/dungeon.jpg')
img_interrogacao = pygame.image.load('imagens/interrogacao2.png')
img_seta = pygame.image.load('imagens/seta2.png')
posicao_interrogacao = img_interrogacao.get_rect(bottomleft=(10, 790))
posicao_seta = img_seta.get_rect(bottomright=(980,780))
#Tentando criar uma borda vermelha escura para o botão iniciar
def borda_no_iniciar(regiao, cor, posicao, tipo_borda):
    pygame.draw.rect(regiao, cor, posicao, border_radius=tipo_borda)

def clique(clicar):
    mouse_x, mouse_y = pygame.mouse.get_pos()
    return clicar.collidepoint(mouse_x, mouse_y)

def nome_do_jogador():
    global nome_resposta
    caixa_resposta = pygame.Rect(400, 400, 00, 50)
    fonte_resposta = pygame.font.SysFont("Times New Roman", 36)
    cor_ativa = azul_claro
    cor_desativada = branco
    cor = cor_desativada
    ativo = False
    texto_resposta = ''
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                if caixa_resposta.collidepoint(event.pos):
                    ativo = not ativo
                else:
                    ativo = False
                cor = cor_ativa if ativo else cor_desativada
            if event.type == KEYDOWN:
                if ativo:
                    if event.key == K_RETURN:
                        return texto_resposta
                    elif event.key == K_BACKSPACE:
                        texto_resposta = texto_resposta[:-1]
                    else:
                        texto_resposta += event.unicode

        tela.blit(img_fundo_selecao_de_personagem,(0,0))
        #tela.fill(preto)
        nome_resposta = fonte_resposta.render(texto_resposta, True, branco)
        largura_box = max(200, nome_resposta.get_width() + 10)
        caixa_resposta.w = largura_box
        tela.blit(nome_resposta, (caixa_resposta.x + 5, caixa_resposta.y + 5))
        pygame.draw.rect(tela, cor, caixa_resposta, 2)
        pergunta_nome_texto = fonte_resposta.render("Qual o Nome do seu Personagem:", True, branco)
        tela.blit(pergunta_nome_texto, (290, 350))
        pygame.display.flip()

def caixa_de_texto_explicativa():
    #Aqui vai ter um cógido, no qual, na seleção de classe, o usuário pode clicar em uma interrogação para ter mais informações sobre a classe escolhida, abrindo uma caixa de texto.
    largura_caixa = 875
    altura_caixa = 150
    tamanho_caixa = pygame.Rect((largura - largura_caixa) // 2, (altura - altura_caixa) // 2, largura_caixa, altura_caixa)
    pygame.draw.rect(tela, preto, tamanho_caixa)
    pygame.draw.rect(tela, vermelho_escuro, tamanho_caixa, 2)
    texto_mago_e_guerreiro_explicativo=[
        "Guerreiro: Nessa classe você terá mais vida e atacará com armas brancas.",
        "Sua honra está em um combate até a morte.",
        "Mago: Nessa classe você terá menos vida, mas poderá causar mais dano com suas poderosas magias.",
        "O conhecimento é seu poder."
    ]
    fonte_explicacao=pygame.font.SysFont("arial", 22)
    espaco_entre_textos = 30
    for i, linha in enumerate(texto_mago_e_guerreiro_explicativo):
        texto=fonte_explicacao.render(linha, True, branco)
        tela.blit(texto, (tamanho_caixa.x + 20, tamanho_caixa.y + 20 + i * espaco_entre_textos))

def selecao_de_classe(nome_jogador):
    global classe_jogador
    #imagem do guerreiro e mago
    img_mago = pygame.image.load("imagens/mago_escolha3_novo.png")
    img_guerreiro = pygame.image.load("imagens/guerreiro_escolha3.png")
    #fonte dos textos abaixo das imagens
    mago_botao_escolha = iniciar_fonte.render("Mago", True, azul)
    guerreiro_botao_escolha = iniciar_fonte.render("Guerreiro", True, azul)
    #posição dos textos e imagens
    posicao_mago_img = img_mago.get_rect(center=(700, 400))
    posicao_mago_texto = mago_botao_escolha.get_rect(center=(720, 600))
    posicao_guerreiro_img = img_guerreiro.get_rect(center=(300, 400))
    posicao_guerreiro_texto = guerreiro_botao_escolha.get_rect(center=(330, 600))
    #Titúlo de "Escolha a sua Classe!"
    texto_fonte_classe= pygame.font.SysFont("Times New Roman", 48)
    texto_classe= texto_fonte_classe.render("Escolha a sua Classe!", True, branco)
    posicao_texto_classe = texto_classe.get_rect(center=(500, 75))

    abrir_caixa_de_texto_explicativa = False
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                if clique(posicao_guerreiro_texto):
                    classe_jogador = "Guerreiro"
                    print("Você escolheu o Guerreiro!")
                    rota_guerreiro(nome_jogador)
                if clique(posicao_mago_texto):
                    classe_jogador = "Mago"
                    rota_mago(nome_jogador)
                    print("Você escolheu o Mago!")
                if clique(posicao_interrogacao):
                    abrir_caixa_de_texto_explicativa = not abrir_caixa_de_texto_explicativa

#Tem que colocar um fundo mais bonito, mas por enquanto tá todo branco(tem que ver como colocar uma imagem real, não só cor)
    #tela.fill(branco) -> Deixar fundo todo branco caso precise tirar a imagem
        #tela.blit(img_fundO_selecao_de_personagem,(0,0))
        tela.fill(preto)
#Fazendo borda no Iniciar
        tela.blit(img_guerreiro, posicao_guerreiro_img)
        tela.blit(img_mago, posicao_mago_img)

#É o que faz os textos aparecerem na tela
        tela.blit(guerreiro_botao_escolha, posicao_guerreiro_texto)
        tela.blit(mago_botao_escolha, posicao_mago_texto)
        tela.blit(texto_classe, posicao_texto_classe)
        tela.blit(img_interrogacao, posicao_interrogacao)
        if abrir_caixa_de_texto_explicativa:
            caixa_de_texto_explicativa()
        pygame.display.update()
#Rota no caso de o jogador escolher guerreiro
def rota_guerreiro(nome_jogador):
    fonte_inicio_rota= pygame.font.SysFont("Garamond", 24)
    texto_de_inicio_rota=fonte_inicio_rota.render(f"Olá {nome_jogador}! Esperamos que como guerreiro, você esteja preparado para a grande aventura que lhe espera!", True, branco)
    posicao_texto_inicial=texto_de_inicio_rota.get_rect(center=(500,400))
    
    tela.fill(preto)
    tela.blit(texto_de_inicio_rota, posicao_texto_inicial)
    tela.blit(img_seta, posicao_seta)

    status_guerreiro=["Guerreiro", 50, 0, 10, 10]
    fonte_status=pygame.font.SysFont("arial", 22)
    mostrar_status=[
        f"Classe: {status_guerreiro[0]}",
        f"Vida: {status_guerreiro[1]}",
        f"Mana: {status_guerreiro[2]}",
        f"Dano: {status_guerreiro[3]}",
        f"Estamina: {status_guerreiro[4]}"
]
    for i, ii in enumerate(mostrar_status):
        status_formatado=fonte_status.render(ii, True, branco)
        posicao_status=status_formatado.get_rect(topleft=(50, 475+ i* 30))
        tela.blit(status_formatado, posicao_status)
    
    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                if clique(posicao_seta):
                    desenhar_mapa()

def rota_mago(nome_jogador):
    fonte_inicio_rota= pygame.font.SysFont("Garamond", 23)
    texto_de_inicio_rota=fonte_inicio_rota.render(f"Olá {nome_jogador}! Esperamos que como mago, você esteja preparado para a grande aventura que lhe espera!", True, branco)
    posicao_texto_inicial=texto_de_inicio_rota.get_rect(center=(500,400))
    
    tela.fill(preto)
    tela.blit(texto_de_inicio_rota, posicao_texto_inicial)
    tela.blit(img_seta, posicao_seta)

    status_mago = ["Mago", 30, 50, 20, 10, 10]
    fonte_status=pygame.font.SysFont("arial", 22)
    mostrar_status=[
        f"Classe: {status_mago[0]}",
        f"Vida: {status_mago[1]}",
        f"Mana: {status_mago[2]}",
        f"Dano da Bola de Fogo: {status_mago[3]}",
        f"Dano do Trovão: {status_mago[4]}",
        f"Estamida: {status_mago[5]}"
]
    for i, ii in enumerate(mostrar_status):
        status_formatado=fonte_status.render(ii, True, branco)
        posicao_status=status_formatado.get_rect(topleft=(50, 475+ i* 30))
        tela.blit(status_formatado, posicao_status)
    
    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                if clique(posicao_seta):
                    desenhar_mapa()
def desenhar_mapa():
    global classe_jogador
    fonte = pygame.font.SysFont('IMPACT', 24)
    tela.blit(img_mapa, (0,0))
    pygame.draw.rect(tela, branco, (0, 700, largura, 100))
    texto_avancar = fonte.render('Avançar',True,preto)
    texto_inventario = fonte.render('Inventário',True,preto)
    pos_txt_avancar = texto_avancar.get_rect(center=(165, 750))
    pos_txt_inventario = texto_inventario.get_rect(center=(830,750))
    tela.blit(texto_avancar,pos_txt_avancar)
    tela.blit(texto_inventario,pos_txt_inventario)
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                if clique(pos_txt_avancar):
                    if classe_jogador == "Guerreiro":
                        resultado = combate_guerreiro()
                    elif classe_jogador == "Mago":
                        resultado = combate_mago()
                    if resultado == "Vitória":
                        desenhar_mapa()
                    elif resultado == "Fugir":
                        desenhar_mapa()
                    elif resultado == "Derrota":
                        menu_inicial()

def combate_guerreiro():
    import Combate_Guerreiro
    Combate_Guerreiro
    global resultado_combate
    resultado_combate = Combate_Guerreiro.main()

def combate_mago():
    import Combate_Mago
    Combate_Mago

# Loop para rodar o menu principal
def menu_inicial():
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                exit()
            if event.type == MOUSEBUTTONDOWN:
                if clique(posicao_iniciar):
                    nome_jogador = nome_do_jogador()
                    print(f"Nome do usuário: {nome_jogador}")
                    selecao_de_classe(nome_jogador)
#Tem que colocar um fundo mais bonito, mas por enquanto tá todo branco(tem que ver como colocar uma imagem real, não só cor)
#tela.fill(branco) -> Deixar fundo todo branco caso precise tirar a imagem
        tela.blit(img_fundo_menu,(0,0))

#Fazendo borda no Iniciar
        posicao_borda_iniciar = posicao_iniciar.inflate(80, 20)
        borda_no_iniciar(tela, vermelho_escuro, posicao_borda_iniciar, 10)

#É o que faz os textos aparecerem na tela
        tela.blit(titulo_jogo, posicao_titulo)
        tela.blit(iniciar_jogo, posicao_iniciar)

#Constante atualização do jogo
        pygame.display.update()
menu_inicial()