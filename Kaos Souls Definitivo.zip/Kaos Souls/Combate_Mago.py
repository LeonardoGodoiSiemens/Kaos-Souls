import pygame
from pygame.locals import *
import sys
import random

pygame.init()

largura = 1000
altura = 800
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Combate")

branco = (255, 255, 255)
preto = (0, 0, 0)
vermelho = (255, 0, 0)

fonte = pygame.font.SysFont("Arial", 24)
# Carregar imagens
img_fundo_combate = pygame.image.load('imagens/img_fundo_selecao_de_personagens.jpg')
img_mago = pygame.image.load('imagens/mago_escolha3_novo.png')
img_esqueleto = pygame.image.load('imagens/Esqueleto.png')
pos_mago = img_mago.get_rect(bottomleft=(30, 690))
pos_esqueleto = img_esqueleto.get_rect(topright=(900, 350))

mago = ["Mago", 30, 50, 20, 10, 10]
esqueleto = ["Esqueleto", 100, 0, 5, 16]

def desenhar_tela(turno):
    tela.blit(img_fundo_combate, (0, 0))
    tela.blit(img_mago, pos_mago)
    tela.blit(img_esqueleto, pos_esqueleto)
    pygame.draw.rect(tela, branco, (0, 700, largura, 100))
    global pos_texto_magia1, pos_texto_magia2, pos_texto_recuperar_mana, pos_texto_descansar, pos_texto_fugir
    # Texto das escolhas
    texto_magia1 = fonte.render("Bola de Fogo", True, preto)
    texto_magia2 = fonte.render("Trovão", True, preto)
    texto_recuperar_mana = fonte.render("Recuperar Mana", True, preto)
    texto_descansar = fonte.render("Descansar", True, preto)
    texto_fugir = fonte.render("Fugir", True, preto)
    # Posição das escolhas
    pos_texto_magia1 = texto_magia1.get_rect(center=(120, 750))
    pos_texto_magia2 = texto_magia2.get_rect(center=(320, 750))
    pos_texto_recuperar_mana = texto_recuperar_mana.get_rect(center=(520, 750))
    pos_texto_descansar = texto_descansar.get_rect(center=(720, 750))
    pos_texto_fugir = texto_fugir.get_rect(center=(920, 750))
    # Mostrar opções na tela
    tela.blit(texto_magia1, pos_texto_magia1)
    tela.blit(texto_magia2, pos_texto_magia2)
    tela.blit(texto_recuperar_mana, pos_texto_recuperar_mana)
    tela.blit(texto_descansar, pos_texto_descansar)
    tela.blit(texto_fugir, pos_texto_fugir)
    # Texto que mostra o turno
    texto_turno = fonte.render(f"Turno: {turno}", True, branco)
    pos_texto_turno = texto_turno.get_rect(topright=(largura - 20, 20))
    tela.blit(texto_turno, pos_texto_turno)
    # Status do mago
    texto_status_mago = fonte.render(f"Mago - Vida: {mago[1]} Mana: {mago[2]} Estamina: {mago[5]}", True, branco)
    pos_texto_status_mago = texto_status_mago.get_rect(bottomright=(980, 680))
    tela.blit(texto_status_mago, pos_texto_status_mago)
    # Status do esqueleto
    texto_status_esqueleto = fonte.render(f"Esqueleto - Vida: {esqueleto[1]} Estamina: {esqueleto[4]}", True, branco)
    pos_texto_status_esqueleto = texto_status_esqueleto.get_rect(bottomleft=(20, 45))
    tela.blit(texto_status_esqueleto, pos_texto_status_esqueleto)
    pygame.display.flip()

def combate_mago():
    turno = 1
    acao_mago = False
    while True:
        desenhar_tela(turno)
        if not acao_mago:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == MOUSEBUTTONDOWN:
                    x, y = event.pos
                    if pos_texto_magia1.collidepoint(x, y):
                        if mago[2] >= 25:
                            print("Mago usou Bola de Fogo!")
                            esqueleto[1] -= mago[3]
                            mago[2] -= 25
                            acao_mago = True
                        else:
                            print("Mago está sem mana para usar Bola de Fogo!")
                    elif pos_texto_magia2.collidepoint(x, y):
                        if mago[2] >= 10:
                            print("Mago usou Trovão!")
                            esqueleto[1] -= mago[4]
                            mago[2] -= 10
                            acao_mago = True
                        else:
                            print("Mago está sem mana para usar Trovão!")
                    elif pos_texto_recuperar_mana.collidepoint(x, y):
                        if mago[5] >= 5:
                            print("Mago recuperou mana!")
                            mago[2] += 20
                            mago[5] -= 5
                            acao_mago = True
                        else:
                            print("Mago está sem estamina para recuperar mana!")
                    elif pos_texto_descansar.collidepoint(x, y):
                        print("Mago descansou!")
                        mago[5] = 10
                        acao_mago = True
                    elif pos_texto_fugir.collidepoint(x, y):
                        print("Mago fugiu!")
                        pygame.quit()
                        sys.exit()
        else:
            acao_mago = False
            if esqueleto[1] <= 0:
                print("Mago venceu!")
                pygame.quit()
                sys.exit()
            elif mago[1] <= 0:
                print("Esqueleto venceu!")
                pygame.quit()
                sys.exit()
            else:
                acao_esqueleto = random.choice(["atacar", "descansar"])
                if acao_esqueleto == "atacar" and esqueleto[4] >= 2:
                    print("Esqueleto ataca!")
                    mago[1] -= esqueleto[3]
                    esqueleto[4] -= 2
                elif acao_esqueleto == "descansar":
                    print("Esqueleto descansa!")
                    esqueleto[4] = 10
                turno += 1

combate_mago()
